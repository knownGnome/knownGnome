# Database Documentation

NoSQL Databases differ from SQL databases as they are not formatted into traditional "tables" with rows and columns. Instead records are organized into documents (the equivalent of rows), with each record containing fields which describe their properties (instead of columns) (more similar to pages in a book). This particular database is implemented using MongoDB. More informations about MongoDB is located in their [documentation](https://docs.mongodb.com/).

## Starting the database

First, ensure that your system has Docker installed (you can install it from [their website](https://www.docker.com/)) and that it is properly configured to download docker images from their online repository. Then, start the docker container for the database using the following command (same for both Windows and UNIX, this assumes that your path includes docker, make sure you have Docker version 2.3.0+ installed and you are in his directory):

```bash
docker-compose up
```

To exit the container, interrupt the process with Ctrl-C, then run:

```bash
docker-compose down
```

Do not alter the `docker-compose.yml` file or the files in the `mongo-entrypoint` directory.

## Connecting to the database

The database username is `softwaredev` and its password is `softwaredev123`. The database is interactable via the default MongoDB port, port 27017.

## Database Schema

The database you will be using is called `softwaredev` and the collection is called `poems`.

The following is the schema for the database (i.e. how each entry in the database is structured):

```json
{
	"_id": number,
	"title": string,
    "author": string,
    "linecount": number,
    "ratings": [ number ],
    "lines": [ string ]
}
```