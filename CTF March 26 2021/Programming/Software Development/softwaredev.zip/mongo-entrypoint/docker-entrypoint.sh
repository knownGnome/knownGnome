#!/usr/bin/env bash

# DO NOT ALTER THIS FILE!

# Import the data into MongoDB
mongoimport --db softwaredev --collection poems \
    --authenticationDatabase admin --username $MONGO_INITDB_ROOT_USERNAME --password $MONGO_INITDB_ROOT_PASSWORD \
    --drop --jsonArray --file /docker-entrypoint-initdb.d/poems.json


# Create the mongo users
echo "Creating mongo users..."
mongo admin --host localhost -u $MONGO_INITDB_ROOT_USERNAME -p $MONGO_INITDB_ROOT_PASSWORD --eval "db.createUser({user: 'softwaredev', pwd: 'softwaredev123', roles: [{role: 'readWrite', db: 'softwaredev'}]});"
echo "Mongo users created."