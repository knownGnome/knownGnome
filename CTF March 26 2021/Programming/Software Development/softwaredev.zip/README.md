# Poetry Database - Software Development Challenge

## Challenge Overview

The purpose of this challenge is to test your software development skills, specifically your ability to produce a complex software solution that meets a customer's requirements, interfaces with external resources, and utilizes existing code bases. Additionally, the challenge will be graded on documentation (in the form of your writeup) / code readability as these are important components of good software development.

## Software Requirements

1. The application shall be compatible on both Windows and UNIX systems.
2. The application shall interface with a NoSQL (MongoDB) database system (you may hardcode the connection into your solution based upon the information in DATABASE.md).
3. The application shall provide the user with a commmand line interface (CLI).
4. The application shall provide the user directory of poems stored in the database showing the title of the poem, the poet and the number of words in the poem, as well as a means of selecting a poem from said directory.
5. Upon selecting a poem from the directory, the application shall show the user the full text of the poem. 
6. The application shall provide the user with the ability to rate each poem on a scale of 1 - 5.
7. The application shall provide the user with an average rating from all submitted user ratings for each poem after the user rates the poem themselves and update the database accordingly.
8. The application shall allow the user to add new poems (not to exceed 1000 words) and their authors via the main directory and update the database accordingly.
9. The application's menu shall have an option to exit the program gracefully.

Your implementation of the above application can be in either Python or C++ (the codebase is provided in both languages). Aside from the requirement to interface with the MongoDB database, there is not limit on how your solution should be implemented: as long as your software can demonstrate meeting the afforementioned requirements, you will be graded favorably.

## External Resources

As mentioned in the requirements section, your application will need to interface with an external resource as well as use an existing code base provided to you. You are NOT allowed to alter the provided code base or the external resource, nor are you allowed to interact with the external resource other than through your application.

## Writeup / Documentation

Your writeup will serve as your documentation for your software application. Your writeup should include:

* Details on how your application is built on the target system
* Details on your application's dependencies
    * Your application should make acquiring those dependencies easy (i.e. use a package manager)
    * A quick dependency scan will be performed to ensure your dependencies do you contain any flagrant, known security risks, so make sure you do the same
* Details on how to use the application to achieve the afforementioned software requirements (with reference to the exact requirements for traceability)

Remember that, aside from your code, this write up is all the customer (i.e. the individual grading your submission) will see, therefore if you do not adequately explain usage, installation, etc. the grader may not be able to properly use your application and will be unable to score it to its full potential.

## Running the Challenge Environment

See DATABASE.md for the documentation on how to start the MongoDB Docker image, how to connect to it, and its schema for interacting with it. For the provided codebase, see INTERFACE.md for the documentation on how to interact with its API.

## What to submit

A single .zip archive containing the following:

- All source code located in a directory labeled `src` (including the software component in the implementation you chose)
- WRITEUP.md (your write up)

**Do not include compiled binaries with your submission**

## Credits

* Docker (http://www.docker.com)
* MongoDB (https://github.com/docker-library/mongo)
* PoetryDB (https://poetrydb.org/index.html)