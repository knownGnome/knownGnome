# Codebase Interface Documentation

This portion of the challenge is meant to simulate a component developed by the organization and provided to you by the organization. You are not allowed to modify the external component and are required to incorporate it into your software solution. You are allowed to look through the source code for the software component to understand how it functions. You can also use this documentation to understand how to interface with it. All component source files are located in the `component/` directory.

**--DOCUMENTATION START--**

# CLI Selector

CLI Selector is a software component that prints a menu of items to the command line and allows the user to select the item using the arrow keys (i.e. scrolling through the options of the menu).

## 1. Example

The following is an example of how the CLI Selector formats its output

```
Menu Title:
    [1] Option 1
    [2] Option 2
    [3] Option 3
    [4] Option 4
    [5] Option 5

> Please select an option using either the arrow UP or DOWN keys to scroll through the options...

[3] Options 3
```

## 2. Implementation

The CLI Selector is implemented in both Python and C++.


## 3. Usage Quick Start

### 3.1. Python

To use the CLI Selector Python module, copy `cliselector.py` into your project directory. On POSIX systems (i.e. Linux, macOS) you will need to install the `getch` module using the pip package manager (`python -m pip install getch`). An example of its usage:

```python
import cliselector # import the module

# initialize the menu
selector = cliselector.CLISelector([ "Option 1", "Option 2", "Option 3", "Option 4" ])
# add an option
selector.addOption("Option 5")
# show the menu, this function blocks until the user provides an input
selection = selector.showMenu("Menu Title")

# the return value of CLISelector.showMenu() is the index of the selected option
print("User chose option:", selection)
```

Given the example usage in Section 1, the last line of the above program would be:

```
User chose option: 2
```

### 3.2. C++

To use the CLI Selector C++ library, copy `cliselector.hpp` into your project directory and add the new header file to your compilation path. Note: this library requires C++11 to work An example of its usage (compiled with the `-std=c++11` flag):

```c++
#include "<iostream>"
#include "cliselector.hpp"

int main() {
    // initialize the menu
    CLISelector::CLISelector selector({ "Option 1", "Option 2", "Option 3", "Option 4" });
    // add a new option
    selector.addOption("Option 5");
    // show the menu, this function will block until the user provides an input
    int selection = selector.showMenu("Menu Title");

    // the return value of CLISelector.showMenu() is the index of the selected option
    std::cout << "User chose option: " << selection << std::endl;
}
```

Given the example usage in Section 1, the last line of the above program would be:

```
User chose option: 2
```

## 4. API Documentation

### 4.1. Python

The Python module is compatible with both Python2 and Python3.

```python
cliselector.CLISelector(optionList)
```

The intializer for the CLISelector object. `optionList` is a list of options (an empty list is also acceptable) for the CLISelector object initializer. Returns reference to object instance.

```python
cliselector.CLISelector.addOption(option)
```

Add a new option string to the list. Returns the index of the newly added object.


```python
cliselector.CLISelector.removeOption(index)
```

Removes an option from the list at the given index. It will return the new size of the menu (i.e. how many options the menu currently contains). Given that the menu is stored as a linked list, this operation will reorganize the menu such that all subsequent options are moved up one index to fill in the gap. It will raise an `IndexError` if `index` is out of bounds.

```python
cliselector.CLISelector.changeOption(index, newValue)
```

Changes the string value of the option at `index` with the `newValue` string provided. Returns `index`. Raises an `IndexError` if `index` is out of bounds. 

```python
cliselector.CLISelector.size()
```

Returns the current size of the menu (i.e. how many options the menu contains)


```python
cliselector.CLISelector.showMenu(title)
```

A blocking function that shows the menu to the user with the title `title`. The user will be able to interact with the menu. The function will block execution until the user submits their choice. This function returns the index of the option selected (NOTE: the user will select from a 1-indexed list, but the function will return the 0-indexed value, i.e. the user selects option 4, the function will return the value 3).

### 4.2. C++

```c++
CLISelector::CLISelector(std::initializer_list<char *> options)
```

The intializer for the CLISelector object. `options` is a list of options (an empty list is also acceptable) for the CLISelector object initializer. NOTE: this function uses `std::initializer_list`, a built-in datatype only provided in C++11 and above. Returns reference to object instance.

```c++
int CLISelector::CLISelector::addOption(char *option);
```

Add a new option string to the list. Returns the index of the newly added object.


```c++
int CLISelector::CLISelector::removeOption(int index);
```

Removes an option from the list at the given index. It will return the new size of the menu (i.e. how many options the menu currently contains). Given that the menu is stored as a linked list, this operation will reorganize the menu such that all subsequent options are moved up one index to fill in the gap. It will return `-1` if the index provided is out of bounds.

```c++
int CLISelector::CLISelector::changeOption(int index, char *newValue);
```

Changes the string value of the option at `index` with the `newValue` string provided. Returns `index` or `-1` if index is out of bounds.

```c++
int CLISelector::CLISelector::size() const;
```

Returns the current size of the menu (i.e. how many options the menu contains)


```c++
int CLISelector::CLISelector::showMenu(const char* title);
```

A blocking function that shows the menu to the user with the title `title`. The user will be able to interact with the menu. The function will block execution until the user submits their choice. This function returns the index of the option selected (NOTE: the user will select from a 1-indexed list, but the function will return the 0-indexed value, i.e. the user selects option 4, the function will return the value 3).

## 5. Dependencies

This component is platform independent and will work on both DOS (Windows) and *NIX (Linux, macOS) environments. The dependencies are language implementation specific.

### 5.1. Python Dependencies

* On all systems, the Python component is dependent on the following built in modules
    * `os`
    * `sys`
    * `signal`
* On Windows systems, the Python component is dependent on the `msvcrt` module, which is a port of the `msvcrt` system library for Python
* On UNIX systems, the Python component is dependent on the `getch` m3rd party module, distributed on Pip and authored by user syscon. It is installable on both Python2 and Python3 using `python -m pip install getch` or `pip install getch`

### 5.2. C++ Dependencies

* On all systems, the C++ component is dependent on the following standard libraries:
    * `<iostream>`
    * `<string>` 
* On Windows systems, the C++ component is dependent on the `<conio.h>` library for reading unbuffered console input (the arrow presses).
* ON UNIX systems, the C++ component has its unbuffered console input implementation built into the header, derived from the code found in [this Stack Overflow answer](https://stackoverflow.com/questions/448944/c-non-blocking-keyboard-input). `ncurses.h` was not used as it takes control of the terminal and therefore does not make this component portable.