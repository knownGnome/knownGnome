#pragma once

#include <initializer_list>
#include <iostream>
#include <string>
#ifdef _WIN32
    #include <conio.h>
    #define GETCH() _getch()
#else
    // Credit: https://stackoverflow.com/questions/448944/c-non-blocking-keyboard-input
    #include <stdlib.h>
    #include <string.h>
    #include <unistd.h>
    #include <sys/select.h>
    #include <termios.h>
    #include <signal.h>

    struct termios orig_termios;

    void reset_terminal_mode()
    {
        tcsetattr(0, TCSANOW, &orig_termios);
    }

    void set_conio_terminal_mode()
    {
        struct termios new_termios;

        /* take two copies - one for now, one for later */
        tcgetattr(0, &orig_termios);
        memcpy(&new_termios, &orig_termios, sizeof(new_termios));

        /* register cleanup handler, and set the new terminal mode */
        atexit(reset_terminal_mode);
        cfmakeraw(&new_termios);
        tcsetattr(0, TCSANOW, &new_termios);
    }

    int getch()
    {
        int r;
        unsigned char c;
        if ((r = read(0, &c, sizeof(c))) < 0) {
            return r;
        } else {
            return c;
        }
    }

    #define GETCH() getch()
#endif

#define MENU_PROMPT "> Please select an option using either the arrow UP or DOWN keys to scroll through the options..."

namespace CLISelector {

class LinkedList {
public: 
    LinkedList() : head(NULL), tail(NULL), len(0) {}
    ~LinkedList() {
        while (head != NULL) {
            NODE *next = head->next;
            delete head;
            head = next;
        }
    }
    int append(std::string value) {
        if (!len) {
            head = new NODE(value);
            tail = head;
        }
        else {
            tail->next = new NODE(tail, value);
            tail = tail->next;
        }
        return ++len;
    }
    int prepend(std::string value) {
        if (!len) {
            head = new NODE(value);
            tail = head;
        }
        else {
            head->prev = new NODE(value, head);
            head = head->prev;
        }
        return 0;
    }
    int remove(int index) {
        if (index < 0 || index >= size()) return -1;
        NODE *cursor = head;
        for (int i = 0; i != index; ++i) {
            cursor = cursor->next;
        }
        cursor->prev->next = cursor->next;
        cursor->next->prev = cursor->prev;
        delete cursor;
        return len--;
    }
    std::string get(int index) const {
        static int current_index = -1;
        static NODE *current_node = NULL;

        if (index < 0 || index >= size()) return NULL;
        if (current_index >= 0 && current_index + 1 == index) {
            ++current_index;
            current_node = current_node->next;
        }
        else if (current_index >= 0 && current_index - 1 == index) {
            --current_index;
            current_node = current_node->prev;
        }
        else if (current_index != index) {
            NODE *cursor = head;
            for (int i = 0; i != index; ++i) {
                cursor = cursor->next;
            }
            current_node = cursor;
            current_index = index;
        }
        return current_node->value;
    }
    int change(int index, std::string value) {
        if (index < 0 || index >= size()) return -1;
        NODE *cursor = head;
        for (int i = 0; i != index; ++i) {
            cursor = cursor->next;
        }
        cursor->value = value;
        return index;
    }
    int size() const { return len; };
private:
    class NODE {
    public:
        NODE(std::string _value) 
            : prev(NULL), next(NULL), value(_value){}
        NODE(std::string _value, NODE *_next) 
            : prev(NULL), next(_next), value(_value){}
        NODE(NODE *_prev, std::string _value) 
            : prev(_prev), next(NULL), value(_value){}
        NODE(NODE *_prev, std::string _value, NODE *_next) 
            : prev(_prev), next(_next), value(_value){}
        NODE *prev;
        NODE *next;
        std::string value;
    };

    NODE *head;
    NODE *tail;
    int len;
};

class CLISelector {
public:
    // Intializer for the CLISelector class, pass in an array of options
    CLISelector(std::initializer_list<std::string> options) {
        for (std::string option : options) {
            menuOptions.append(option);
        }
    }
    // Add an new option to the menu
    int addOption(std::string option) {
        return menuOptions.append(option);
    }
    // Remove an option from the menu
    int removeOption(int index) {
        return menuOptions.remove(index);
    }
    // Alter the text of a specific option in the menu
    int changeOption(int index, std::string newValue) {
        return menuOptions.change(index, newValue);
    }
    // Get the number of options in the menu
    int size() const { return menuOptions.size(); }
    // Show the menu and return the selected index
    int showMenu(const char * title) const { 
        int current_index = 0;
        int new_index = 0;
        int length = size();
        std::cout << title << std::endl;
        for (int i = 0; i < length; ++i) {
            std::cout << "\t[" << i + 1 << "] " << menuOptions.get(i) << std::endl;
        }
        std::cout << '\n' << MENU_PROMPT << '\n' << std::endl;
        std::cout << "[1] " << menuOptions.get(0) << std::flush;
        #ifndef _WIN32
            set_conio_terminal_mode();
        #endif
        while (1) {
            char ch = GETCH();
            #ifdef _WIN32
            if (ch == 0 || ch == 224) {
            #else 
            if (ch == 91) {
            #endif
                switch (GETCH()) {
                    case 72:
                        new_index = (current_index + (length - 1)) % length;
                        echoNewLine(std::cout, current_index, new_index);
                        current_index = new_index;
                        break;
                    case 80:
                        new_index = (current_index + (length + 1)) % length;
                        echoNewLine(std::cout, current_index, new_index);
                        current_index = new_index;
                        break;
                }
            }
            else if (ch == '\r') {
                std::cout << '\r' << std::endl;
                break;
            }
            #ifndef _WIN32
            if (ch == 3) {
                raise(SIGINT);
            }
            #endif
        }
        #ifndef _WIN32
            reset_terminal_mode();
        #endif
        return current_index;
    }
private:
    int numDigits(int x) const { 
        return (x < 10 ? 1 :   
            (x < 100 ? 2 :   
            (x < 1000 ? 3 :   
            (x < 10000 ? 4 :   
            (x < 100000 ? 5 :   
            (x < 1000000 ? 6 :   
            (x < 10000000 ? 7 :  
            (x < 100000000 ? 8 :  
            (x < 1000000000 ? 9 :  
            10)))))))));  
    } 
    void echoNewLine(std::ostream& os, int old_index, int new_index) const {
        int old_num_len = 3 + numDigits(old_index + 1) + menuOptions.get(old_index).size();
        // Clear the current line
        os << '\r' << std::string(old_num_len, ' ')
           << "\r[" << new_index + 1 << "] " << menuOptions.get(new_index) << std::flush;
    }
    LinkedList menuOptions;
};

};