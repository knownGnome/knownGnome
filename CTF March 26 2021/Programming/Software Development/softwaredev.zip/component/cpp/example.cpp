#include <iostream>
#include "cliselector.hpp"

int main() {
    // initialize the menu
    CLISelector::CLISelector selector({ "Option 1", "Option 2", "Option 3", "Option 4" });
    // add a new option
    selector.addOption("Option 5");
    // show the menu, this function will block until the user provides an input
    int selection = selector.showMenu("Menu Title");

    // the return value of CLISelector.showMenu() is the index of the selected option
    std::cout << "User chose option: " << selection << std::endl;
}