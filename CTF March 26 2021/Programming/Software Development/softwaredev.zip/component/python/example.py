import cliselector # import the module

# initialize the menu
selector = cliselector.CLISelector([ "Option 1", "Option 2", "Option 3", "Option 4" ])
# add an option
selector.addOption("Option 5")
# show the menu, this function blocks until the user provides an input
selection = selector.showMenu("Menu Title")

# the return value of CLISelector.showMenu() is the index of the selected option
print("User chose option:", selection)