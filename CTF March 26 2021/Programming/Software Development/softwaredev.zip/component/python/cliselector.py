import os
import sys
import signal
if os.name == 'posix' :
    from getch import getch
else :
    from msvcrt import getch

promptString = "> Please select an option using either the arrow UP or DOWN keys to scroll through the options..."

class CLISelector() :
    def __init__(self, options) :
        self.options = []
        for i in options :
            self.options.append(i)

    def addOption(self, newOption) :
        self.options.append(newOption)
        return len(self.options) - 1
    
    def removeOption(self, index) :
        if index < 0 or index > len(self.options) :
            raise IndexError
        self.options.pop(index)
        return len(self.options)
    
    def changeOption(self, index, newValue) :
        if index < 0 or index > len(self.options) :
            raise IndexError
        self.options[index] = newValue
        return index

    def size(self) :
        return len(self.options)
    
    def __printNew(self, oldIndex, newIndex) :
        oldLineLen = len(str(oldIndex + 1)) + 3 + len(self.options[oldIndex])
        sys.stdout.write("\r%s\r[%d] %s" % ((" " * oldLineLen), newIndex + 1, self.options[newIndex]) )

    def showMenu(self, title) :
        current_index = 0
        length = self.size()
        print(title)
        for i in range(len(self.options)) :
            print("\t[%d] %s" % (i + 1, self.options[i]))
        
        print("\n%s\n" % (promptString))
        sys.stdout.write("[%d] %s" % (current_index + 1, self.options[current_index]))
        sys.stdout.flush()

        prep = 0
        while True:
            c = ord(getch())
            if os.name == 'posix' :
                if c == 10 :
                    print("\r")
                    break
                elif c == 27:
                    prep = 1
                elif c == 91 and prep == 1:
                    prep = 2
                elif c == 65 and prep == 2 :
                    new_index = (current_index + (length - 1)) % length
                    self.__printNew(current_index, new_index)
                    current_index = new_index
                elif c == 66 and prep == 2 :
                    new_index = (current_index + (length + 1)) % length
                    self.__printNew(current_index, new_index)
                    current_index = new_index
                else :
                    prep = 0
            else :
                if c == 3 :
                    signal.raise_signal(signal.SIGINT)
                elif c == 13 :
                    print("\r")
                    break
                elif c == 224 :
                    prep = 1
                elif c == 72 and prep == 1 :
                    new_index = (current_index + (length - 1)) % length
                    self.__printNew(current_index, new_index)
                    current_index = new_index
                elif c == 80 and prep == 1 :
                    new_index = (current_index + (length + 1)) % length
                    self.__printNew(current_index, new_index)
                    current_index = new_index

        return current_index